# Refine Auth - Prototipo de Autenticação

Aplicação React usando **Refine Core** para implementar autenticação com a mesma API do projeto `custom-auth`.

## 🚀 Tecnologias

- **React 18**
- **Refine Core** - Framework de gerenciamento de estado e auth
- **React Router v6** - Roteamento
- **Vite** - Build tool

## 📦 Instalação

```bash
npm install
```

## 🏃‍♂️ Executar

```bash
npm run dev
```

A aplicação estará disponível em: `http://localhost:5174`

## 🔐 Funcionamento

### 1. **authProvider** (`src/authProvider.js`)
Implementa a integração com a API:
- **login()** - Faz GET em `/token` e salva no localStorage
- **check()** - Valida token via POST em `/auth`
- **logout()** - Remove token do localStorage

### 2. **Rotas Protegidas**
O componente `<Authenticated>` do Refine protege automaticamente as rotas:
- Se não autenticado → redireciona para `/login`
- Se autenticado → acessa conteúdo protegido

### 3. **Páginas**
- **LoginPage** - Botão para fazer login via API
- **ProtectedPage** - Conteúdo visível apenas após autenticação

## 🔗 API

Certifique-se de que a API está rodando na porta **3001**:

```bash
node api/index.js
```

Endpoints utilizados:
- `GET /token` - Gera novo token
- `POST /auth` - Valida token existente

## 📊 Comparação com SvelteKit

| Recurso | SvelteKit (custom-auth) | Refine |
|---------|-------------------------|--------|
| Auth Management | Manual com `auth.js` | `authProvider` integrado |
| Proteção de rotas | Componente `<Authenticated>` customizado | `<Authenticated>` do Refine |
| Storage | localStorage direto | localStorage via authProvider |
| Validação | `onMount` + `verifyToken()` | Hook `check()` automático |
| Redirecionamento | Manual | Automático via Refine |

## 🎯 Recursos do Refine Utilizados

- ✅ **authProvider** - Gerenciamento de autenticação
- ✅ **Authenticated Component** - Proteção de rotas
- ✅ **useLogin** - Hook para login
- ✅ **useLogout** - Hook para logout
- ✅ **useGetIdentity** - Hook para dados do usuário
- ✅ **Router Integration** - Integração com React Router v6
