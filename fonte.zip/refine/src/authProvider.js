const API_URL = "http://127.0.0.1:3001";

export const authProvider = {
  // Faz login chamando a API /token
  login: async () => {
    try {
      const response = await fetch(`${API_URL}/token`, {
        method: "GET",
      });

      if (response.status === 200) {
        const data = await response.json();
        localStorage.setItem("token", data.token);
        return {
          success: true,
          redirectTo: "/",
        };
      }

      return {
        success: false,
        error: {
          name: "LoginError",
          message: "Erro ao fazer login",
        },
      };
    } catch (error) {
      return {
        success: false,
        error: {
          name: "LoginError",
          message: error.message,
        },
      };
    }
  },

  // Remove o token do localStorage
  logout: async () => {
    localStorage.removeItem("token");
    return {
      success: true,
      redirectTo: "/login",
    };
  },

  // Verifica se o usuário está autenticado chamando /auth
  check: async () => {
    try {
      const token = localStorage.getItem("token");

      if (!token) {
        return {
          authenticated: false,
          redirectTo: "/login",
        };
      }

      const response = await fetch(`${API_URL}/auth`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ token }),
      });

      if (response.status === 200) {
        return {
          authenticated: true,
        };
      }

      localStorage.removeItem("token");
      return {
        authenticated: false,
        redirectTo: "/login",
      };
    } catch (error) {
      return {
        authenticated: false,
        redirectTo: "/login",
      };
    }
  },

  // Retorna erros de autenticação
  onError: async (error) => {
    if (error.status === 401) {
      return {
        logout: true,
        redirectTo: "/login",
      };
    }

    return {};
  },

  // Obtém informações do usuário (opcional)
  getIdentity: async () => {
    const token = localStorage.getItem("token");

    if (token) {
      return {
        id: 1,
        name: "Usuário Autenticado",
      };
    }

    return null;
  },
};
