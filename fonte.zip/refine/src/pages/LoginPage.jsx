import { useLogin } from "@refinedev/core";

export const LoginPage = () => {
  const { mutate: login, isLoading } = useLogin();

  const handleLogin = () => {
    login({});
  };

  return (
    <div style={styles.container}>
      <div style={styles.card}>
        <h1 style={styles.title}>Refine Auth</h1>
        <p style={styles.description}>
          Clique no botão abaixo para fazer login via API
        </p>
        <button
          onClick={handleLogin}
          disabled={isLoading}
          style={styles.button}
        >
          {isLoading ? "Carregando..." : "Fazer Login"}
        </button>
      </div>
    </div>
  );
};

const styles = {
  container: {
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    minHeight: "100vh",
    background: "linear-gradient(135deg, #667eea 0%, #764ba2 100%)",
  },
  card: {
    background: "white",
    padding: "40px",
    borderRadius: "12px",
    boxShadow: "0 10px 40px rgba(0,0,0,0.2)",
    textAlign: "center",
    maxWidth: "400px",
  },
  title: {
    color: "#333",
    marginBottom: "20px",
  },
  description: {
    color: "#666",
    marginBottom: "30px",
  },
  button: {
    background: "#667eea",
    color: "white",
    border: "none",
    padding: "12px 30px",
    borderRadius: "6px",
    fontSize: "16px",
    cursor: "pointer",
    transition: "background 0.3s",
  },
};
