import { useLogout, useGetIdentity } from "@refinedev/core";

export const ProtectedPage = () => {
  const { mutate: logout } = useLogout();
  const { data: identity } = useGetIdentity();

  const handleLogout = () => {
    logout();
  };

  return (
    <div style={styles.container}>
      <div style={styles.card}>
        <h1 style={styles.title}>✅ Área Protegida</h1>
        <div style={styles.content}>
          <p style={styles.text}>
            Você está autenticado! Este conteúdo só é exibido após validação do token pela API.
          </p>
          {identity && (
            <p style={styles.identity}>
              Bem-vindo, <strong>{identity.name}</strong>
            </p>
          )}
          <div style={styles.info}>
            <p>Token salvo no localStorage</p>
            <p>Validação via POST /auth</p>
          </div>
          <button onClick={handleLogout} style={styles.button}>
            Fazer Logout
          </button>
        </div>
      </div>
    </div>
  );
};

const styles = {
  container: {
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    minHeight: "100vh",
    background: "linear-gradient(135deg, #11998e 0%, #38ef7d 100%)",
  },
  card: {
    background: "white",
    padding: "40px",
    borderRadius: "12px",
    boxShadow: "0 10px 40px rgba(0,0,0,0.2)",
    maxWidth: "500px",
  },
  title: {
    color: "#11998e",
    marginBottom: "20px",
    textAlign: "center",
  },
  content: {
    color: "#333",
  },
  text: {
    fontSize: "18px",
    marginBottom: "20px",
    lineHeight: "1.6",
  },
  identity: {
    background: "#f0f0f0",
    padding: "15px",
    borderRadius: "8px",
    marginBottom: "20px",
  },
  info: {
    background: "#e8f5e9",
    padding: "15px",
    borderRadius: "8px",
    marginBottom: "20px",
    fontSize: "14px",
  },
  button: {
    background: "#dc3545",
    color: "white",
    border: "none",
    padding: "12px 30px",
    borderRadius: "6px",
    fontSize: "16px",
    cursor: "pointer",
    width: "100%",
    transition: "background 0.3s",
  },
};
