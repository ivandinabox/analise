export const manifest = (() => {
function __memo(fn) {
	let value;
	return () => value ??= (value = fn());
}

return {
	appDir: "_app",
	appPath: "_app",
	assets: new Set(["robots.txt"]),
	mimeTypes: {".txt":"text/plain"},
	_: {
		client: {start:"_app/immutable/entry/start.fA2rdn7h.js",app:"_app/immutable/entry/app.DWLnCp9m.js",imports:["_app/immutable/entry/start.fA2rdn7h.js","_app/immutable/chunks/B9LKpMij.js","_app/immutable/chunks/GIGGycJc.js","_app/immutable/entry/app.DWLnCp9m.js","_app/immutable/chunks/GIGGycJc.js","_app/immutable/chunks/CHncfsjL.js","_app/immutable/chunks/D1hYfEew.js"],stylesheets:[],fonts:[],uses_env_dynamic_public:false},
		nodes: [
			__memo(() => import('./nodes/0.js')),
			__memo(() => import('./nodes/1.js'))
		],
		remotes: {
			
		},
		routes: [
			
		],
		prerendered_routes: new Set(["/","/login","/protected"]),
		matchers: async () => {
			
			return {  };
		},
		server_assets: {}
	}
}
})();
