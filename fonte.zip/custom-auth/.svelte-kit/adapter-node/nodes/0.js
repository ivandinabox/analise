

export const index = 0;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/_layout.svelte.js')).default;
export const imports = ["_app/immutable/nodes/0.w9Pxcoeu.js","_app/immutable/chunks/xZ2jR8Kh.js","_app/immutable/chunks/D1hYfEew.js"];
export const stylesheets = ["_app/immutable/assets/0.Cnvx01aS.css"];
export const fonts = [];
