

export const index = 2;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/2.Du8u61z9.js","_app/immutable/chunks/xZ2jR8Kh.js","_app/immutable/chunks/D1hYfEew.js","_app/immutable/chunks/BysxSPmM.js"];
export const stylesheets = ["_app/immutable/assets/2.BrzbG8dA.css"];
export const fonts = [];
