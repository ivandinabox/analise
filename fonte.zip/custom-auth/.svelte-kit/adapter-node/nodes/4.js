

export const index = 4;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/protected/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/4.Cz7oldws.js","_app/immutable/chunks/xZ2jR8Kh.js","_app/immutable/chunks/D1hYfEew.js","_app/immutable/chunks/BysxSPmM.js"];
export const stylesheets = ["_app/immutable/assets/4.CmsHqsVm.css"];
export const fonts = [];
