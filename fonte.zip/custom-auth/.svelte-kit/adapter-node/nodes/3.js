

export const index = 3;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/login/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/3.yDOoEvz-.js","_app/immutable/chunks/xZ2jR8Kh.js","_app/immutable/chunks/D1hYfEew.js","_app/immutable/chunks/BysxSPmM.js"];
export const stylesheets = ["_app/immutable/assets/3.q5aAaGIF.css"];
export const fonts = [];
