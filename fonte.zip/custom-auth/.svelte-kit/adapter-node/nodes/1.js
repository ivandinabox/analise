

export const index = 1;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/fallbacks/error.svelte.js')).default;
export const imports = ["_app/immutable/nodes/1.AHQLxCcD.js","_app/immutable/chunks/xZ2jR8Kh.js","_app/immutable/chunks/C2Zbz4bZ.js","_app/immutable/chunks/D1hYfEew.js"];
export const stylesheets = [];
export const fonts = [];
