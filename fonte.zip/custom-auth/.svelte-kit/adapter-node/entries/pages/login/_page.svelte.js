import { F as escape_html, P as attr } from "../../../chunks/dev.js";
//#region src/routes/login/+page.svelte
function _page($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		$$renderer.push(`<div class="container svelte-1x05zx6"><div class="card svelte-1x05zx6"><h1 class="title svelte-1x05zx6">SvelteKit Auth</h1> <p class="description svelte-1x05zx6">Clique no botão abaixo para fazer login via API</p> <button${attr("disabled", false, true)} class="button svelte-1x05zx6">${escape_html("Fazer Login")}</button></div></div>`);
	});
}
//#endregion
export { _page as default };
