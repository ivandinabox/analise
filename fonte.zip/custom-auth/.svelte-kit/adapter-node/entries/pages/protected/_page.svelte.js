import "../../../chunks/index-server.js";
import "../../../chunks/dev.js";
import "../../../chunks/auth.js";
//#region src/lib/components/Authenticated.svelte
function Authenticated($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		let { children } = $$props;
		$$renderer.push("<!--[0-->");
		$$renderer.push(`<div class="loading svelte-4ooo1j">Verificando autenticação...</div>`);
		$$renderer.push(`<!--]-->`);
	});
}
//#endregion
//#region src/routes/protected/+page.svelte
function _page($$renderer) {
	Authenticated($$renderer, {
		children: ($$renderer) => {
			$$renderer.push(`<div class="container svelte-1mtgg9"><div class="card svelte-1mtgg9"><h1 class="title svelte-1mtgg9">✅ Área Protegida</h1> <div class="content svelte-1mtgg9"><p class="text svelte-1mtgg9">Você está autenticado! Este conteúdo só é exibido após validação do
          token pela API.</p> <div class="identity svelte-1mtgg9"><p>Bem-vindo, <strong>Usuário Autenticado</strong></p></div> <div class="info svelte-1mtgg9"><p class="svelte-1mtgg9">Token salvo no localStorage</p> <p class="svelte-1mtgg9">Validação via POST /auth</p></div> <button class="button svelte-1mtgg9">Fazer Logout</button></div></div></div>`);
		},
		$$slots: { default: true }
	});
}
//#endregion
export { _page as default };
