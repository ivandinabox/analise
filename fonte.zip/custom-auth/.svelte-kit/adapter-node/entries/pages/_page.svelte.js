import "../../chunks/index-server.js";
import "../../chunks/dev.js";
import "../../chunks/auth.js";
//#region src/routes/+page.svelte
function _page($$renderer, $$props) {
	$$renderer.component(($$renderer) => {
		$$renderer.push(`<div class="container svelte-1uha8ag"><div class="card svelte-1uha8ag"><h1 class="svelte-1uha8ag">Carregando...</h1></div></div>`);
	});
}
//#endregion
export { _page as default };
