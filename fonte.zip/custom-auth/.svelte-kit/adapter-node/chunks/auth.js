//#region src/lib/auth/auth.js
async function verifyToken() {
	try {
		const token = localStorage.getItem("token");
		if (!token) return false;
		const res = await fetch("http://127.0.0.1:3001/auth", {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify({ token })
		});
		if (res.status === 200) return true;
		else if (res.status === 401) return false;
		return false;
	} catch (error) {
		console.error("Erro ao verificar token:", error);
		return false;
	}
}
//#endregion
export { verifyToken as t };
