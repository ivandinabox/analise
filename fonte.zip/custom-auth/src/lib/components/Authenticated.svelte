<script>
  import { onMount } from "svelte";
  import { verifyToken } from "$lib/auth/auth.js";

  let { children } = $props();
  let authenticated = $state(false);
  let loading = $state(true);

  onMount(async () => {
    const isAuthenticated = await verifyToken();
    if (isAuthenticated) {
      authenticated = true;
    } else {
      window.location.href = "/login";
    }
    loading = false;
  });
</script>

{#if loading}
  <div class="loading">Verificando autenticação...</div>
{:else if authenticated}
  {@render children?.()}
{/if}

<style>
  .loading {
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
    font-size: 18px;
    color: #666;
  }
</style>
