<script>
  import Authenticated from "$lib/components/Authenticated.svelte";

  function handleLogout() {
    localStorage.removeItem("token");
    window.location.href = "/login";
  }
</script>

<Authenticated>
  <div class="container">
    <div class="card">
      <h1 class="title">✅ Área Protegida</h1>
      <div class="content">
        <p class="text">
          Você está autenticado! Este conteúdo só é exibido após validação do
          token pela API.
        </p>

        <div class="identity">
          <p>
            Bem-vindo, <strong>Usuário Autenticado</strong>
          </p>
        </div>

        <div class="info">
          <p>Token salvo no localStorage</p>
          <p>Validação via POST /auth</p>
        </div>

        <button onclick={handleLogout} class="button"> Fazer Logout </button>
      </div>
    </div>
  </div>
</Authenticated>

<style>
  .container {
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
    background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%);
  }

  .card {
    background: white;
    padding: 40px;
    border-radius: 12px;
    box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2);
    max-width: 500px;
    width: 100%;
  }

  .title {
    color: #11998e;
    margin-bottom: 20px;
    text-align: center;
    font-size: 2rem;
  }

  .content {
    color: #333;
  }

  .text {
    font-size: 18px;
    margin-bottom: 20px;
    line-height: 1.6;
  }

  .identity {
    background: #f0f0f0;
    padding: 15px;
    border-radius: 8px;
    margin-bottom: 20px;
  }

  .info {
    background: #e8f5e9;
    padding: 15px;
    border-radius: 8px;
    margin-bottom: 20px;
    font-size: 14px;
  }

  .info p {
    margin: 5px 0;
  }

  .button {
    background: #dc3545;
    color: white;
    border: none;
    padding: 12px 30px;
    border-radius: 6px;
    font-size: 16px;
    cursor: pointer;
    width: 100%;
    transition: background 0.3s;
    font-family: inherit;
    text-decoration: none;
    display: inline-block;
    text-align: center;
  }

  .button:hover {
    background: #c82333;
  }
</style>
