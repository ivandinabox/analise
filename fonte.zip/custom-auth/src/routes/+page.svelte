<script>
  import { onMount } from "svelte";
  import { verifyToken } from "$lib/auth/auth.js";

  onMount(async () => {
    const isAuthenticated = await verifyToken();
    if (isAuthenticated) {
      window.location.href = "/protected";
    } else {
      window.location.href = "/login";
    }
  });
</script>

<div class="container">
  <div class="card">
    <h1>Carregando...</h1>
  </div>
</div>

<style>
  .container {
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  }

  .card {
    background: white;
    padding: 40px;
    border-radius: 12px;
    box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2);
    text-align: center;
  }

  h1 {
    color: #333;
    font-size: 1.5rem;
  }
</style>
