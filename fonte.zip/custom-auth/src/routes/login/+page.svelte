<script>
  import { login } from "$lib/auth/auth.js";

  let isLoading = $state(false);

  async function handleLogin() {
    isLoading = true;
    try {
      await login();
      window.location.href = "/protected";
    } catch (error) {
      console.error("Erro no login:", error);
    } finally {
      isLoading = false;
    }
  }
</script>

<div class="container">
  <div class="card">
    <h1 class="title">SvelteKit Auth</h1>
    <p class="description">Clique no botão abaixo para fazer login via API</p>
    <button onclick={handleLogin} disabled={isLoading} class="button">
      {isLoading ? "Carregando..." : "Fazer Login"}
    </button>
  </div>
</div>

<style>
  .container {
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  }

  .card {
    background: white;
    padding: 40px;
    border-radius: 12px;
    box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2);
    text-align: center;
    max-width: 400px;
    width: 100%;
  }

  .title {
    color: #333;
    margin-bottom: 20px;
    font-size: 2rem;
  }

  .description {
    color: #666;
    margin-bottom: 30px;
    line-height: 1.6;
  }

  .button {
    background: #667eea;
    color: white;
    border: none;
    padding: 12px 30px;
    border-radius: 6px;
    font-size: 16px;
    cursor: pointer;
    transition: background 0.3s;
    font-family: inherit;
  }

  .button:hover:not(:disabled) {
    background: #5568d3;
  }

  .button:disabled {
    opacity: 0.6;
    cursor: not-allowed;
  }
</style>
