const express = require('express');
const app = express();
const PORT = process.env.PORT || 3001;
var tokens = {};

setInterval(() => {
  console.clear();
  console.log("Verificando Tokens:", tokens);
  let keys = Object.keys(tokens);
  for (let i = 0; i < keys.length; i++) {
    if (verifyToken(tokens[keys[i]]) == false) {
      console.log("Token expirado: ", keys[i], tokens[keys[i]]);
      delete tokens[keys[i]];
    }
  }
}, 10000);
app.use(express.json());

// Configuração CORS - Libera todas as origens
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  // Responde requisições OPTIONS (preflight)
  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  next();
});

// Endpoint de OK
app.get('/token', (req, res) => {
  let time = new Date().getTime();
  let expires = time + 30000;
  let token = "token_" + time.toString().substring(7);

  tokens[token] = expires;

  res.status(200).json({
    status: 'OK',
    token: token
  });
});

function verifyToken(tokenExpirationTime) {
  let time = new Date().getTime();

  if (tokenExpirationTime > time) {
    return true;
  } else {
    return false;
  }
}

// Endpoint de OK
app.get('/ok', (req, res) => {
  res.status(200).json({
    status: 'OK',
    message: 'API está funcionando!'
  });
});

app.post('/auth', function (req, res) {
  console.log("Auth", req.body.token);
  if (req.body.token && verifyToken(tokens[req.body.token])) {
    res.status(200).json({
      status: 'OK',
      message: 'autorizado'
    });
  } else {
    res.status(401).json({
      status: 'error',
      message: 'não autorizado'
    });
  }
});

app.listen(PORT, () => {
  console.log(`Servidor rodando na porta ${PORT}`);
});
